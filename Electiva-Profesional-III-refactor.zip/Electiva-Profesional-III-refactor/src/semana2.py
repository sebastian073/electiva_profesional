print('Demo ejecutado: reemplaza con tu lógica original')
