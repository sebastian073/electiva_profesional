def test_demo():
    assert 1+1==2
